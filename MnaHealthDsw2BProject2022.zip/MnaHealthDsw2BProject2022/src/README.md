# MNA_HEALTH DSW02B1  Project
To Get A Request Of The Nearest Hospital;
https://cors-anywhere.herokuapp.com/

Don't forget to install all of our dependencies that you may find inside our files (package and package-lock)
